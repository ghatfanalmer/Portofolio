import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Phone, c as Menu, d as Copy, f as Check, i as Printer, l as MapPin, o as Moon, p as ArrowDown, r as Sun, s as MessageCircle, t as X, u as Mail } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-GrkfQorE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var EMAIL = "hello@vandermorder.com";
var PHONE = "+62 812 4600 1996";
var PHONE_HREF = "tel:+6281246001996";
var WA_HREF = "https://wa.me/6281246001996";
var NAV = [
	{
		id: "identitas",
		label: "Identitas"
	},
	{
		id: "perjalanan",
		label: "Perjalanan"
	},
	{
		id: "karya",
		label: "Karya"
	},
	{
		id: "kontak",
		label: "Kontak"
	}
];
var IDENTITY = [
	{
		label: "Nama lengkap",
		value: "Vander Lucien Morder"
	},
	{
		label: "Nama panggilan",
		value: "Vander"
	},
	{
		label: "Jenis kelamin",
		value: "Laki-laki"
	},
	{
		label: "Tempat lahir",
		value: "Bandung"
	},
	{
		label: "Tanggal lahir",
		value: "14 Maret 1996"
	},
	{
		label: "Usia",
		value: "30 tahun"
	},
	{
		label: "Kewarganegaraan",
		value: "Indonesia"
	},
	{
		label: "Domisili",
		value: "Kemang, Jakarta Selatan"
	},
	{
		label: "Status",
		value: "Belum menikah"
	},
	{
		label: "Profesi",
		value: "Creative Director"
	},
	{
		label: "Studio",
		value: "Atelier Morder"
	},
	{
		label: "Bahasa",
		value: "Indonesia · Inggris · Prancis"
	}
];
var STUDY = [{
	when: "2019",
	title: "Program singkat tipografi",
	place: "École de Condé, Paris"
}, {
	when: "2014 — 2018",
	title: "S1 Desain Komunikasi Visual",
	place: "Institut Teknologi Bandung"
}];
var JOURNEY = [
	{
		when: "2022 — kini",
		title: "Creative Director",
		place: "Atelier Morder · Jakarta",
		body: "Mendirikan studio kecil untuk identitas merek, editorial, dan ruang. Mengarahkan tim tiga orang, dari sketsa sampai sistem yang bisa dipakai klien sendiri."
	},
	{
		when: "2019 — 2022",
		title: "Senior Designer",
		place: "Studio Utara · Bandung",
		body: "Memimpin proyek hospitality dan budaya. Di sinilah ritme tropis dan disiplin tipografi Eropa mulai duduk dalam satu bahasa visual."
	},
	{
		when: "2018",
		title: "Desainer editorial",
		place: "Majalah Ruang · magang",
		body: "Menata halaman, memilih kertas, dan belajar bahwa ruang kosong bisa lebih keras daripada ornamen."
	}
];
var WORKS = [
	{
		year: "2025",
		name: "Seroja",
		kind: "Identitas rumah kopi",
		role: "Arah visual"
	},
	{
		year: "2024",
		name: "Laut Senyap",
		kind: "Hotel pantai, Lombok",
		role: "Brand & ruang"
	},
	{
		year: "2023",
		name: "Edisi Utara",
		kind: "Majalah independen",
		role: "Desain editorial"
	},
	{
		year: "2022",
		name: "Atelier Morder",
		kind: "Studio sendiri",
		role: "Sistem identitas"
	}
];
var SKILLS = [
	"Identitas merek",
	"Art direction",
	"Tipografi",
	"Editorial",
	"Motion",
	"Fotografi",
	"Sistem visual",
	"Ruang & pameran"
];
function ThemeSwitch() {
	const [dark, setDark] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setDark(document.documentElement.classList.contains("dark"));
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		className: "theme-switch",
		"aria-pressed": dark,
		"aria-label": dark ? "Ganti ke mode terang" : "Ganti ke mode gelap",
		onClick: () => {
			const next = !document.documentElement.classList.contains("dark");
			document.documentElement.classList.toggle("dark", next);
			localStorage.setItem("vm-theme", next ? "dark" : "light");
			setDark(next);
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, {
				className: "theme-sun",
				"aria-hidden": true,
				strokeWidth: 1.75
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, {
				className: "theme-moon",
				"aria-hidden": true,
				strokeWidth: 1.75
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "theme-knob" })
		]
	});
}
function JakartaClock() {
	const [time, setTime] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const format = () => new Intl.DateTimeFormat("id-ID", {
			hour: "2-digit",
			minute: "2-digit",
			second: "2-digit",
			hour12: false,
			timeZone: "Asia/Jakarta"
		}).format(/* @__PURE__ */ new Date());
		setTime(format());
		const id = window.setInterval(() => setTime(format()), 1e3);
		return () => window.clearInterval(id);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "clock",
		children: [time ?? "--:--:--", " WIB"]
	});
}
function NavLinks({ active, onNavigate }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		href: `#${item.id}`,
		"aria-current": active === item.id ? "true" : void 0,
		onClick: onNavigate,
		children: item.label
	}, item.id)) });
}
function BiodataPage() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [active, setActive] = (0, import_react.useState)("");
	const [copied, setCopied] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const root = document.documentElement;
		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
		const onMove = (event) => {
			root.style.setProperty("--mx", `${event.clientX}px`);
			root.style.setProperty("--my", `${event.clientY}px`);
		};
		window.addEventListener("pointermove", onMove, { passive: true });
		return () => window.removeEventListener("pointermove", onMove);
	}, []);
	(0, import_react.useEffect)(() => {
		const nodes = NAV.map((item) => document.getElementById(item.id)).filter((node) => node !== null);
		const observer = new IntersectionObserver((entries) => {
			const visible = entries.filter((entry) => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
			if (visible?.target.id) setActive(visible.target.id);
		}, {
			rootMargin: "-45% 0px -48% 0px",
			threshold: [.1, .3]
		});
		nodes.forEach((node) => observer.observe(node));
		return () => observer.disconnect();
	}, []);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const onKey = (event) => {
			if (event.key === "Escape") setOpen(false);
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [open]);
	async function copyEmail() {
		try {
			await navigator.clipboard.writeText(EMAIL);
		} catch {
			const field = document.createElement("textarea");
			field.value = EMAIL;
			document.body.appendChild(field);
			field.select();
			document.execCommand("copy");
			field.remove();
		}
		setCopied(true);
		window.setTimeout(() => setCopied(false), 1800);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "page",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "ambient",
				"aria-hidden": true,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "bubble b1" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "bubble b2" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "bubble b3" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "bubble b4" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "bubble b5" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "bubble b6" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "bubble b7" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "spotlight",
				"aria-hidden": true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "site-header",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "skip",
						href: "#konten",
						children: "Lewati ke isi"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "nav-shell glass",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								className: "wordmark",
								href: "#atas",
								children: "vander morder"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
								className: "nav-links",
								"aria-label": "Bagian biodata",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLinks, { active })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "nav-actions",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "icon-btn",
									"aria-expanded": open,
									"aria-controls": "menu-mobile",
									onClick: () => setOpen((value) => !value),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, {
											className: open ? "ico hide" : "ico",
											"aria-hidden": true,
											strokeWidth: 1.75
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
											className: open ? "ico" : "ico hide",
											"aria-hidden": true,
											strokeWidth: 1.75
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "sr",
											children: "Menu"
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemeSwitch, {})]
							})
						]
					}),
					open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						id: "menu-mobile",
						className: "mobile-panel glass",
						"aria-label": "Bagian biodata",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLinks, {
							active,
							onNavigate: () => setOpen(false)
						})
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				id: "konten",
				className: "wrap",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "atas",
						className: "hero-grid",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "kicker glass rise d1",
								children: "Biodata pribadi"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
								className: "display-name",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rise d2",
									children: "Vander"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rise d3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "Morder" })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "role-line rise d4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Creative Director" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										"aria-hidden": true,
										children: "·"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(JakartaClock, {})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "lede rise d5",
								children: "Creative director yang membangun identitas visual dari studio kecil di Kemang. Tenang di permukaan, teliti di dalam — huruf, jarak, bahan, dan cahaya."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "actions rise d5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									className: "btn btn-solid",
									href: "#identitas",
									children: ["Lihat identitas", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, {
										"aria-hidden": true,
										strokeWidth: 1.75
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									className: "btn btn-glass",
									href: "#kontak",
									children: ["Hubungi", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, {
										"aria-hidden": true,
										strokeWidth: 1.75
									})]
								})]
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "orb-stage rise d3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "liquid",
									"aria-hidden": true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "orb-wrap",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "orb-spin-clip",
										"aria-hidden": true,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "orb-spin" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "orb-glass",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											className: "portrait",
											src: "/portrait.jpg",
											alt: "Potret ilustrasi Vander Morder, berkemeja gading dengan latar krem",
											width: 900,
											height: 1200,
											fetchPriority: "high"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "orb-spec",
											"aria-hidden": true
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "sats",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "sat glass sat-a",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "10 thn" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "praktik" })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "sat glass sat-b",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "proyek" })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "sat glass sat-c",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "bahasa" })]
										})
									]
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "identitas",
						className: "section",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
							className: "section-head",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "idx",
								children: "01"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Identitas" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Data diri yang biasanya diminta paling dulu." })] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "glass panel",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "panel-label",
								children: "Profil"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								role: "table",
								"aria-label": "Identitas Vander Morder",
								className: "rows",
								children: IDENTITY.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									role: "row",
									className: "glass-row",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										role: "rowheader",
										children: row.label
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										role: "cell",
										children: row.value
									})]
								}, row.label))
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "section",
						"aria-labelledby": "tentang-judul",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
							className: "section-head",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "idx",
								children: "02"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								id: "tentang-judul",
								children: "Tentang"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Cara kerja, bukan daftar sifat." })] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "about-grid",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "glass about-copy",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Saya tidak mengumpulkan gaya. Saya menyusun ritme sampai sebuah merek terasa seperti tempat yang sudah lama dikenal." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Klien biasanya rumah kopi, hotel kecil, penerbit, dan studio yang ingin dikenang tanpa berteriak. Dari Kemang, pekerjaan itu dikirim ke mana pun yang membutuhkan ketenangan yang sama." })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", {
								className: "glass quote",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("q", { children: "Ruang kosong yang hangat lebih sulit daripada ornamen. Di situlah pekerjaan saya." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Catatan studio" })]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "perjalanan",
						className: "section",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
							className: "section-head",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "idx",
								children: "03"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Perjalanan" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Kerja dan pendidikan, dari Bandung ke Paris lalu kembali ke Jakarta." })] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "split",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "glass panel",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "panel-label",
									children: "Pengalaman"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
									className: "journey",
									children: JOURNEY.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
										className: "glass-row",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "when",
												children: item.when
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: item.title }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "place",
												children: item.place
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: item.body })
										] })
									}, item.title))
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "glass panel",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "panel-label",
									children: "Pendidikan"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									role: "table",
									"aria-label": "Pendidikan",
									className: "rows",
									children: STUDY.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										role: "row",
										className: "glass-row",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											role: "rowheader",
											children: item.when
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											role: "cell",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: item.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
												className: "place",
												children: item.place
											})]
										})]
									}, item.title))
								})]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "karya",
						className: "section",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
								className: "section-head",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "idx",
									children: "04"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Karya" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Beberapa pekerjaan yang masih sering dibuka lagi." })] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "glass panel",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "panel-label",
									children: "Pilihan proyek"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									role: "table",
									"aria-label": "Karya pilihan",
									className: "rows",
									children: WORKS.map((work) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										role: "row",
										className: "glass-row work-row",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "year",
												role: "cell",
												children: work.year
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												role: "cell",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: work.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: work.kind })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "work-role",
												role: "cell",
												children: work.role
											})
										]
									}, work.name))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "glass skill-cloud after-panel",
								children: SKILLS.map((skill) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "skill",
									children: skill
								}, skill))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "hobby",
								children: "Di luar studio: film 35mm, jazz malam, arsitektur tropis, dan kopi yang diseduh pelan."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "kontak",
						className: "section",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
							className: "section-head",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "idx",
								children: "05"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Kontak" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Studio buka Senin sampai Jumat, pukul 10.00–18.00 WIB." })] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "glass panel",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "panel-label",
									children: "Hubungi Vander"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									role: "table",
									"aria-label": "Kontak",
									className: "rows",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											role: "row",
											className: "glass-row",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												role: "rowheader",
												children: "Email"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												role: "cell",
												className: "cell-with-action",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
													href: `mailto:${EMAIL}`,
													children: EMAIL
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "button",
													className: "mini-btn",
													onClick: copyEmail,
													children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
														"aria-hidden": true,
														strokeWidth: 1.75
													}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {
														"aria-hidden": true,
														strokeWidth: 1.75
													}), copied ? "Tersalin" : "Salin"]
												})]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											role: "row",
											className: "glass-row",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												role: "rowheader",
												children: "Telepon"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												role: "cell",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
													href: PHONE_HREF,
													children: PHONE
												})
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											role: "row",
											className: "glass-row",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												role: "rowheader",
												children: "Studio"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												role: "cell",
												children: "Jalan Kemang Raya, Jakarta Selatan"
											})]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "contact-actions",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
											className: "btn btn-solid",
											href: `mailto:${EMAIL}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, {
												"aria-hidden": true,
												strokeWidth: 1.75
											}), "Kirim email"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
											className: "btn btn-glass",
											href: PHONE_HREF,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
												"aria-hidden": true,
												strokeWidth: 1.75
											}), "Telepon"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
											className: "btn btn-glass",
											href: WA_HREF,
											target: "_blank",
											rel: "noreferrer",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, {
												"aria-hidden": true,
												strokeWidth: 1.75
											}), "WhatsApp"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											className: "btn btn-glass no-print",
											onClick: () => window.print(),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, {
												"aria-hidden": true,
												strokeWidth: 1.75
											}), "Cetak"]
										})
									]
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
						className: "footer",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "© 2026 Vander Morder" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "pin",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { "aria-hidden": true }), "Jakarta Selatan"]
						})]
					})
				]
			})
		]
	});
}
var SplitComponent = BiodataPage;
//#endregion
export { SplitComponent as component };
