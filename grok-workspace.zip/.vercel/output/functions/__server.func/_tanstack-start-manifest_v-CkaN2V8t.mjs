//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CkaN2V8t.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		css: ["/assets/index-DWq0xuCJ.css"],
		preloads: ["/assets/index-BSk15kqG.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BSk15kqG.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DdgtRvKk.js"]
	}
} });
//#endregion
export { tsrStartManifest };
