import { useEffect, useState } from "react";
import {
  ArrowDown,
  Check,
  Copy,
  Mail,
  MapPin,
  Menu,
  MessageCircle,
  Moon,
  Phone,
  Printer,
  Sun,
  X,
} from "lucide-react";

const EMAIL = "hello@vandermorder.com";
const PHONE = "+62 812 4600 1996";
const PHONE_HREF = "tel:+6281246001996";
const WA_HREF = "https://wa.me/6281246001996";

const NAV = [
  { id: "identitas", label: "Identitas" },
  { id: "perjalanan", label: "Perjalanan" },
  { id: "karya", label: "Karya" },
  { id: "kontak", label: "Kontak" },
] as const;

const IDENTITY: { label: string; value: string }[] = [
  { label: "Nama lengkap", value: "Vander Lucien Morder" },
  { label: "Nama panggilan", value: "Vander" },
  { label: "Jenis kelamin", value: "Laki-laki" },
  { label: "Tempat lahir", value: "Bandung" },
  { label: "Tanggal lahir", value: "14 Maret 1996" },
  { label: "Usia", value: "30 tahun" },
  { label: "Kewarganegaraan", value: "Indonesia" },
  { label: "Domisili", value: "Kemang, Jakarta Selatan" },
  { label: "Status", value: "Belum menikah" },
  { label: "Profesi", value: "Creative Director" },
  { label: "Studio", value: "Atelier Morder" },
  { label: "Bahasa", value: "Indonesia · Inggris · Prancis" },
];

const STUDY = [
  { when: "2019", title: "Program singkat tipografi", place: "École de Condé, Paris" },
  { when: "2014 — 2018", title: "S1 Desain Komunikasi Visual", place: "Institut Teknologi Bandung" },
];

const JOURNEY = [
  {
    when: "2022 — kini",
    title: "Creative Director",
    place: "Atelier Morder · Jakarta",
    body: "Mendirikan studio kecil untuk identitas merek, editorial, dan ruang. Mengarahkan tim tiga orang, dari sketsa sampai sistem yang bisa dipakai klien sendiri.",
  },
  {
    when: "2019 — 2022",
    title: "Senior Designer",
    place: "Studio Utara · Bandung",
    body: "Memimpin proyek hospitality dan budaya. Di sinilah ritme tropis dan disiplin tipografi Eropa mulai duduk dalam satu bahasa visual.",
  },
  {
    when: "2018",
    title: "Desainer editorial",
    place: "Majalah Ruang · magang",
    body: "Menata halaman, memilih kertas, dan belajar bahwa ruang kosong bisa lebih keras daripada ornamen.",
  },
];

const WORKS = [
  { year: "2025", name: "Seroja", kind: "Identitas rumah kopi", role: "Arah visual" },
  { year: "2024", name: "Laut Senyap", kind: "Hotel pantai, Lombok", role: "Brand & ruang" },
  { year: "2023", name: "Edisi Utara", kind: "Majalah independen", role: "Desain editorial" },
  { year: "2022", name: "Atelier Morder", kind: "Studio sendiri", role: "Sistem identitas" },
];

const SKILLS = [
  "Identitas merek",
  "Art direction",
  "Tipografi",
  "Editorial",
  "Motion",
  "Fotografi",
  "Sistem visual",
  "Ruang & pameran",
];

function ThemeSwitch() {
  const [dark, setDark] = useState(false);

  useEffect(() => {
    setDark(document.documentElement.classList.contains("dark"));
  }, []);

  return (
    <button
      type="button"
      className="theme-switch"
      aria-pressed={dark}
      aria-label={dark ? "Ganti ke mode terang" : "Ganti ke mode gelap"}
      onClick={() => {
        const next = !document.documentElement.classList.contains("dark");
        document.documentElement.classList.toggle("dark", next);
        localStorage.setItem("vm-theme", next ? "dark" : "light");
        setDark(next);
      }}
    >
      <Sun className="theme-sun" aria-hidden strokeWidth={1.75} />
      <Moon className="theme-moon" aria-hidden strokeWidth={1.75} />
      <span className="theme-knob" />
    </button>
  );
}

function JakartaClock() {
  const [time, setTime] = useState<string | null>(null);

  useEffect(() => {
    const format = () =>
      new Intl.DateTimeFormat("id-ID", {
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hour12: false,
        timeZone: "Asia/Jakarta",
      }).format(new Date());
    setTime(format());
    const id = window.setInterval(() => setTime(format()), 1000);
    return () => window.clearInterval(id);
  }, []);

  return <span className="clock">{time ?? "--:--:--"} WIB</span>;
}

function NavLinks({
  active,
  onNavigate,
}: {
  active: string;
  onNavigate?: () => void;
}) {
  return (
    <>
      {NAV.map((item) => (
        <a
          key={item.id}
          href={`#${item.id}`}
          aria-current={active === item.id ? "true" : undefined}
          onClick={onNavigate}
        >
          {item.label}
        </a>
      ))}
    </>
  );
}

export function BiodataPage() {
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState("");
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const root = document.documentElement;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) return;
    const onMove = (event: PointerEvent) => {
      root.style.setProperty("--mx", `${event.clientX}px`);
      root.style.setProperty("--my", `${event.clientY}px`);
    };
    window.addEventListener("pointermove", onMove, { passive: true });
    return () => window.removeEventListener("pointermove", onMove);
  }, []);

  useEffect(() => {
    const nodes = NAV.map((item) => document.getElementById(item.id)).filter(
      (node): node is HTMLElement => node !== null,
    );
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible?.target.id) setActive(visible.target.id);
      },
      { rootMargin: "-45% 0px -48% 0px", threshold: [0.1, 0.3] },
    );
    nodes.forEach((node) => observer.observe(node));
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  async function copyEmail() {
    try {
      await navigator.clipboard.writeText(EMAIL);
    } catch {
      const field = document.createElement("textarea");
      field.value = EMAIL;
      document.body.appendChild(field);
      field.select();
      document.execCommand("copy");
      field.remove();
    }
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1800);
  }

  return (
    <div className="page">
      <div className="ambient" aria-hidden>
        <span className="bubble b1" />
        <span className="bubble b2" />
        <span className="bubble b3" />
        <span className="bubble b4" />
        <span className="bubble b5" />
        <span className="bubble b6" />
        <span className="bubble b7" />
      </div>
      <div className="spotlight" aria-hidden />

      <header className="site-header">
        <a className="skip" href="#konten">
          Lewati ke isi
        </a>
        <div className="nav-shell glass">
          <a className="wordmark" href="#atas">
            vander morder
          </a>
          <nav className="nav-links" aria-label="Bagian biodata">
            <NavLinks active={active} />
          </nav>
          <div className="nav-actions">
            <button
              type="button"
              className="icon-btn"
              aria-expanded={open}
              aria-controls="menu-mobile"
              onClick={() => setOpen((value) => !value)}
            >
              <Menu className={open ? "ico hide" : "ico"} aria-hidden strokeWidth={1.75} />
              <X className={open ? "ico" : "ico hide"} aria-hidden strokeWidth={1.75} />
              <span className="sr">Menu</span>
            </button>
            <ThemeSwitch />
          </div>
        </div>
        {open ? (
          <nav id="menu-mobile" className="mobile-panel glass" aria-label="Bagian biodata">
            <NavLinks active={active} onNavigate={() => setOpen(false)} />
          </nav>
        ) : null}
      </header>

      <main id="konten" className="wrap">
        <section id="atas" className="hero-grid">
          <div>
            <p className="kicker glass rise d1">Biodata pribadi</p>
            <h1 className="display-name">
              <span className="rise d2">Vander</span>
              <span className="rise d3">
                <em>Morder</em>
              </span>
            </h1>
            <p className="role-line rise d4">
              <span>Creative Director</span>
              <span aria-hidden>·</span>
              <JakartaClock />
            </p>
            <p className="lede rise d5">
              Creative director yang membangun identitas visual dari studio kecil di Kemang.
              Tenang di permukaan, teliti di dalam — huruf, jarak, bahan, dan cahaya.
            </p>
            <div className="actions rise d5">
              <a className="btn btn-solid" href="#identitas">
                Lihat identitas
                <ArrowDown aria-hidden strokeWidth={1.75} />
              </a>
              <a className="btn btn-glass" href="#kontak">
                Hubungi
                <Mail aria-hidden strokeWidth={1.75} />
              </a>
            </div>
          </div>

          <div className="orb-stage rise d3">
            <div className="liquid" aria-hidden />
            <div className="orb-wrap">
              <div className="orb-spin-clip" aria-hidden>
                <div className="orb-spin" />
              </div>
              <div className="orb-glass">
                <img
                  className="portrait"
                  src="/portrait.jpg"
                  alt="Potret ilustrasi Vander Morder, berkemeja gading dengan latar krem"
                  width={900}
                  height={1200}
                  fetchPriority="high"
                />
                <span className="orb-spec" aria-hidden />
              </div>
            </div>
            <div className="sats">
              <p className="sat glass sat-a">
                <strong>10 thn</strong>
                <span>praktik</span>
              </p>
              <p className="sat glass sat-b">
                <strong>40</strong>
                <span>proyek</span>
              </p>
              <p className="sat glass sat-c">
                <strong>3</strong>
                <span>bahasa</span>
              </p>
            </div>
          </div>
        </section>

        <section id="identitas" className="section">
          <header className="section-head">
            <span className="idx">01</span>
            <div>
              <h2>Identitas</h2>
              <p>Data diri yang biasanya diminta paling dulu.</p>
            </div>
          </header>
          <div className="glass panel">
            <p className="panel-label">Profil</p>
            <div role="table" aria-label="Identitas Vander Morder" className="rows">
              {IDENTITY.map((row) => (
                <div role="row" className="glass-row" key={row.label}>
                  <span role="rowheader">{row.label}</span>
                  <span role="cell">{row.value}</span>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="section" aria-labelledby="tentang-judul">
          <header className="section-head">
            <span className="idx">02</span>
            <div>
              <h2 id="tentang-judul">Tentang</h2>
              <p>Cara kerja, bukan daftar sifat.</p>
            </div>
          </header>
          <div className="about-grid">
            <div className="glass about-copy">
              <p>
                Saya tidak mengumpulkan gaya. Saya menyusun ritme sampai sebuah merek terasa
                seperti tempat yang sudah lama dikenal.
              </p>
              <p>
                Klien biasanya rumah kopi, hotel kecil, penerbit, dan studio yang ingin dikenang
                tanpa berteriak. Dari Kemang, pekerjaan itu dikirim ke mana pun yang membutuhkan
                ketenangan yang sama.
              </p>
            </div>
            <blockquote className="glass quote">
              <q>Ruang kosong yang hangat lebih sulit daripada ornamen. Di situlah pekerjaan saya.</q>
              <span>Catatan studio</span>
            </blockquote>
          </div>
        </section>

        <section id="perjalanan" className="section">
          <header className="section-head">
            <span className="idx">03</span>
            <div>
              <h2>Perjalanan</h2>
              <p>Kerja dan pendidikan, dari Bandung ke Paris lalu kembali ke Jakarta.</p>
            </div>
          </header>
          <div className="split">
            <div className="glass panel">
              <p className="panel-label">Pengalaman</p>
              <ol className="journey">
                {JOURNEY.map((item) => (
                  <li className="glass-row" key={item.title}>
                    <div>
                      <p className="when">{item.when}</p>
                      <h3>{item.title}</h3>
                      <p className="place">{item.place}</p>
                      <p>{item.body}</p>
                    </div>
                  </li>
                ))}
              </ol>
            </div>
            <div className="glass panel">
              <p className="panel-label">Pendidikan</p>
              <div role="table" aria-label="Pendidikan" className="rows">
                {STUDY.map((item) => (
                  <div role="row" className="glass-row" key={item.title}>
                    <span role="rowheader">{item.when}</span>
                    <span role="cell">
                      <strong>{item.title}</strong>
                      <em className="place">{item.place}</em>
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section id="karya" className="section">
          <header className="section-head">
            <span className="idx">04</span>
            <div>
              <h2>Karya</h2>
              <p>Beberapa pekerjaan yang masih sering dibuka lagi.</p>
            </div>
          </header>
          <div className="glass panel">
            <p className="panel-label">Pilihan proyek</p>
            <div role="table" aria-label="Karya pilihan" className="rows">
              {WORKS.map((work) => (
                <div role="row" className="glass-row work-row" key={work.name}>
                  <span className="year" role="cell">
                    {work.year}
                  </span>
                  <span role="cell">
                    <strong>{work.name}</strong>
                    <em>{work.kind}</em>
                  </span>
                  <span className="work-role" role="cell">
                    {work.role}
                  </span>
                </div>
              ))}
            </div>
          </div>
          <div className="glass skill-cloud after-panel">
            {SKILLS.map((skill) => (
              <span className="skill" key={skill}>
                {skill}
              </span>
            ))}
          </div>
          <p className="hobby">
            Di luar studio: film 35mm, jazz malam, arsitektur tropis, dan kopi yang diseduh pelan.
          </p>
        </section>

        <section id="kontak" className="section">
          <header className="section-head">
            <span className="idx">05</span>
            <div>
              <h2>Kontak</h2>
              <p>Studio buka Senin sampai Jumat, pukul 10.00–18.00 WIB.</p>
            </div>
          </header>
          <div className="glass panel">
            <p className="panel-label">Hubungi Vander</p>
            <div role="table" aria-label="Kontak" className="rows">
              <div role="row" className="glass-row">
                <span role="rowheader">Email</span>
                <span role="cell" className="cell-with-action">
                  <a href={`mailto:${EMAIL}`}>{EMAIL}</a>
                  <button type="button" className="mini-btn" onClick={copyEmail}>
                    {copied ? (
                      <Check aria-hidden strokeWidth={1.75} />
                    ) : (
                      <Copy aria-hidden strokeWidth={1.75} />
                    )}
                    {copied ? "Tersalin" : "Salin"}
                  </button>
                </span>
              </div>
              <div role="row" className="glass-row">
                <span role="rowheader">Telepon</span>
                <span role="cell">
                  <a href={PHONE_HREF}>{PHONE}</a>
                </span>
              </div>
              <div role="row" className="glass-row">
                <span role="rowheader">Studio</span>
                <span role="cell">Jalan Kemang Raya, Jakarta Selatan</span>
              </div>
            </div>
            <div className="contact-actions">
              <a className="btn btn-solid" href={`mailto:${EMAIL}`}>
                <Mail aria-hidden strokeWidth={1.75} />
                Kirim email
              </a>
              <a className="btn btn-glass" href={PHONE_HREF}>
                <Phone aria-hidden strokeWidth={1.75} />
                Telepon
              </a>
              <a className="btn btn-glass" href={WA_HREF} target="_blank" rel="noreferrer">
                <MessageCircle aria-hidden strokeWidth={1.75} />
                WhatsApp
              </a>
              <button type="button" className="btn btn-glass no-print" onClick={() => window.print()}>
                <Printer aria-hidden strokeWidth={1.75} />
                Cetak
              </button>
            </div>
          </div>
        </section>

        <footer className="footer">
          <p>© 2026 Vander Morder</p>
          <p className="pin">
            <MapPin aria-hidden />
            Jakarta Selatan
          </p>
        </footer>
      </main>
    </div>
  );
}
