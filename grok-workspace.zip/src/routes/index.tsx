import { createFileRoute } from "@tanstack/react-router";
import { BiodataPage } from "@/components/biodata-page";

export const Route = createFileRoute("/")({
  component: BiodataPage,
});
